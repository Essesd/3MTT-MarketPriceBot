public class HelloWorld {
    public static void main(String[] args) {
        System.out.println("Hello, World! Java is ready to use!");
        System.out.println("You can write any Java code you need here.");
    }
}