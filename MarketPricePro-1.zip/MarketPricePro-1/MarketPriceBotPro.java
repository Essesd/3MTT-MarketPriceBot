import java.util.HashMap;
import java.util.Map;
import java.util.Random;
import java.util.Scanner;
import java.util.ArrayList;
import java.util.List;

public class MarketPriceBotPro {
    // ANSI Color codes for professional styling
    public static final String RESET = "\u001B[0m";
    public static final String GREEN = "\u001B[32m";
    public static final String BLUE = "\u001B[34m";
    public static final String YELLOW = "\u001B[33m";
    public static final String RED = "\u001B[31m";
    public static final String CYAN = "\u001B[36m";
    public static final String PURPLE = "\u001B[35m";
    public static final String BOLD = "\u001B[1m";
    public static final String WHITE_BG = "\u001B[47m";
    public static final String GREEN_BG = "\u001B[42m";
    
    // Feedback and rating system
    private static Map<String, List<Integer>> productRatings = new HashMap<>();
    private static Map<String, List<String>> productFeedback = new HashMap<>();
    private static int totalFeedbackCount = 0;

    public static void main(String[] args) {
        // Clear screen for a fresh start
        clearScreen();
        
        // Professional welcome banner
        displayWelcomeBanner();
        
        // Sample dataset of goods and price ranges
        Map<String, Map<String, Integer>> marketPrices = new HashMap<>();
        
        // Nigerian market tips with enhanced styling
        String[] tips = {
            "💡 " + YELLOW + "Haggle small-small o!" + RESET,
            "⏰ " + BLUE + "Check market early for better deals!" + RESET,
            "💰 " + GREEN + "Na beta price for bulk buying!" + RESET,
            "🎁 " + PURPLE + "Ask for bonus if you buy plenty!" + RESET,
            "📍 " + CYAN + "Compare prices across different markets!" + RESET
        };
        
        Random random = new Random();
        System.out.println("\n" + GREEN + "🔥 TODAY'S TIP: " + tips[random.nextInt(tips.length)] + "\n" + RESET);

        // Initialize all price data with enhanced organization
        initializeMarketData(marketPrices);

        // Start the professional chatbot interface
        runProfessionalChatbot(marketPrices);
    }

    private static void clearScreen() {
        try {
            if (System.getProperty("os.name").contains("Windows")) {
                new ProcessBuilder("cmd", "/c", "cls").inheritIO().start().waitFor();
            } else {
                System.out.print("\033[2J\033[H");
            }
        } catch (Exception e) {
            // If clearing fails, just add some spacing
            for (int i = 0; i < 3; i++) System.out.println();
        }
    }

    private static void displayWelcomeBanner() {
        System.out.println(GREEN + BOLD + 
        "╔══════════════════════════════════════════════════════════════════╗" + RESET);
        System.out.println(GREEN + BOLD + 
        "║" + WHITE_BG + "                    🛒 MARKET PRICE BOT PRO 🛒                     " + RESET + GREEN + BOLD + "║" + RESET);
        System.out.println(GREEN + BOLD + 
        "║" + "                    Nigerian Market Intelligence                    " + "║" + RESET);
        System.out.println(GREEN + BOLD + 
        "╠══════════════════════════════════════════════════════════════════╣" + RESET);
        System.out.println(GREEN + BOLD + 
        "║" + YELLOW + "  🌟 Real-time Nigerian Market Prices                           " + GREEN + BOLD + "║" + RESET);
        System.out.println(GREEN + BOLD + 
        "║" + BLUE + "  🔍 Smart Search with Auto-complete                            " + GREEN + BOLD + "║" + RESET);
        System.out.println(GREEN + BOLD + 
        "║" + PURPLE + "  📊 Professional Price Analysis                                " + GREEN + BOLD + "║" + RESET);
        System.out.println(GREEN + BOLD + 
        "║" + CYAN + "  💰 Get the best deals in Nigerian markets!                    " + GREEN + BOLD + "║" + RESET);
        System.out.println(GREEN + BOLD + 
        "╚══════════════════════════════════════════════════════════════════╝" + RESET);
    }

    private static void initializeMarketData(Map<String, Map<String, Integer>> marketPrices) {
        // Vegetables
        addItem(marketPrices, "tomato", 2300, 2700, 2500);
        addItem(marketPrices, "onion", 18000, 22000, 20000);
        addItem(marketPrices, "pepper", 8000, 12000, 10000);
        addItem(marketPrices, "garlic", 25000, 30000, 27500);
        addItem(marketPrices, "ginger", 8000, 12000, 10000);

        // Grains & Staples
        addItem(marketPrices, "rice", 85000, 100000, 90000);
        addItem(marketPrices, "beans", 1400, 2500, 2000);
        addItem(marketPrices, "garri", 37000, 45000, 40000);
        addItem(marketPrices, "millet", 4000, 4500, 4200);
        addItem(marketPrices, "maize", 35000, 42000, 38500);
        addItem(marketPrices, "soyabeans", 45000, 55000, 50000);
        addItem(marketPrices, "cassava", 15000, 20000, 17500);
        addItem(marketPrices, "flour", 14000, 22000, 16000);

        // Fruits
        addItem(marketPrices, "plantain", 1500, 2200, 1800);

        // Others
        addItem(marketPrices, "groundnut", 7000, 7500, 7150);
        addItem(marketPrices, "salt", 2000, 2500, 1500);
        addItem(marketPrices, "sugar", 45000, 49000, 42000);
        addItem(marketPrices, "noodles", 8500, 10000, 9000);
        addItem(marketPrices, "yam", 3000, 7000, 5000);

        // Oils
        addItem(marketPrices, "oil", 8500, 10000, 9000);
        addItem(marketPrices, "palmoil", 18000, 25000, 22000);

        // Protein
        addItem(marketPrices, "fish", 12000, 18000, 15000);
        addItem(marketPrices, "chicken", 4500, 6000, 5200);
        addItem(marketPrices, "eggs", 3500, 4200, 3800);
    }

    private static void addItem(Map<String, Map<String, Integer>> marketPrices, String name, int min, int max, int avg) {
        Map<String, Integer> prices = new HashMap<>();
        prices.put("min", min);
        prices.put("max", max);
        prices.put("avg", avg);
        marketPrices.put(name, prices);
    }

    private static void runProfessionalChatbot(Map<String, Map<String, Integer>> marketPrices) {
        Scanner scanner = new Scanner(System.in);
        
        System.out.println(CYAN + BOLD + "\n🚀 COMMANDS:" + RESET);
        System.out.println(YELLOW + "  • Type any product name (e.g., 'rice', 'tom' for tomato)" + RESET);
        System.out.println(BLUE + "  • 'help' - Show all available products" + RESET);
        System.out.println(PURPLE + "  • 'feedback' - View accuracy ratings and user feedback" + RESET);
        System.out.println(RED + "  • 'quit' - Exit the application" + RESET);
        System.out.println(GREEN + "═══════════════════════════════════════════════════════════════════" + RESET);

        while (true) {
            System.out.print(BOLD + BLUE + "\n💬 What product price do you need? " + RESET + "» ");
            String userInput = scanner.nextLine().toLowerCase().trim();

            if (userInput.equals("quit") || userInput.equals("exit")) {
                displayGoodbyeMessage();
                break;
            }

            if (userInput.equals("help")) {
                displayProfessionalHelp();
                continue;
            }

            if (userInput.equals("feedback")) {
                displayFeedbackSummary();
                continue;
            }

            handleProductSearch(userInput, marketPrices, scanner);
        }

        scanner.close();
    }

    private static void displayProfessionalHelp() {
        System.out.println(GREEN + BOLD + "\n╔═══════════════════════════════════════════════════════════════════╗" + RESET);
        System.out.println(GREEN + BOLD + "║" + CYAN + BOLD + "                        📋 PRODUCT CATALOG                          " + GREEN + BOLD + "║" + RESET);
        System.out.println(GREEN + BOLD + "╠═══════════════════════════════════════════════════════════════════╣" + RESET);
        
        System.out.println(GREEN + BOLD + "║" + RESET + " 🥬 " + YELLOW + BOLD + "VEGETABLES:" + RESET + " tomato, onion, pepper, garlic, ginger           " + GREEN + BOLD + "║" + RESET);
        System.out.println(GREEN + BOLD + "║" + RESET + " 🌾 " + YELLOW + BOLD + "GRAINS:" + RESET + " rice, beans, garri, millet, maize, soyabeans       " + GREEN + BOLD + "║" + RESET);
        System.out.println(GREEN + BOLD + "║" + RESET + " 🍌 " + YELLOW + BOLD + "FRUITS:" + RESET + " plantain, yam                                      " + GREEN + BOLD + "║" + RESET);
        System.out.println(GREEN + BOLD + "║" + RESET + " 🥜 " + YELLOW + BOLD + "STAPLES:" + RESET + " cassava, flour, groundnut, salt, sugar, noodles   " + GREEN + BOLD + "║" + RESET);
        System.out.println(GREEN + BOLD + "║" + RESET + " 🛢️ " + YELLOW + BOLD + "OILS:" + RESET + " cooking oil, palm oil                              " + GREEN + BOLD + "║" + RESET);
        System.out.println(GREEN + BOLD + "║" + RESET + " 🐟 " + YELLOW + BOLD + "PROTEIN:" + RESET + " fish, chicken, eggs                               " + GREEN + BOLD + "║" + RESET);
        
        System.out.println(GREEN + BOLD + "╠═══════════════════════════════════════════════════════════════════╣" + RESET);
        System.out.println(GREEN + BOLD + "║" + BLUE + " 💡 PRO TIP: Use shortcuts like 'tom' for tomato, 'ric' for rice!  " + GREEN + BOLD + "║" + RESET);
        System.out.println(GREEN + BOLD + "╚═══════════════════════════════════════════════════════════════════╝" + RESET);
    }

    private static void handleProductSearch(String userInput, Map<String, Map<String, Integer>> marketPrices, Scanner scanner) {
        String foundItem = findProduct(userInput, marketPrices);

        if (foundItem != null) {
            displayProductInfo(foundItem, marketPrices.get(foundItem), !foundItem.equals(userInput));
            promptForFeedback(foundItem, scanner);
        } else {
            displayNotFoundMessage(userInput, marketPrices);
        }
    }

    private static String findProduct(String userInput, Map<String, Map<String, Integer>> marketPrices) {
        // Exact match first
        if (marketPrices.containsKey(userInput)) {
            return userInput;
        }

        // Partial match (minimum 3 characters)
        if (userInput.length() >= 3) {
            for (String item : marketPrices.keySet()) {
                if (item.startsWith(userInput)) {
                    return item;
                }
            }
        }

        return null;
    }

    private static void displayProductInfo(String product, Map<String, Integer> prices, boolean wasPartialMatch) {
        System.out.println(GREEN + "\n╔══════════════════════════════════════════════════════════════════╗" + RESET);
        System.out.println(GREEN + "║" + CYAN + BOLD + "                    📊 PRICE ANALYSIS REPORT                      " + GREEN + "║" + RESET);
        System.out.println(GREEN + "╠══════════════════════════════════════════════════════════════════╣" + RESET);
        
        String capitalizedProduct = product.substring(0, 1).toUpperCase() + product.substring(1);
        System.out.println(GREEN + "║" + RESET + " 🏷️  " + YELLOW + BOLD + "PRODUCT: " + RESET + capitalizedProduct + 
                          String.format("%" + (47 - capitalizedProduct.length()) + "s", "") + GREEN + "║" + RESET);
        
        System.out.println(GREEN + "║" + RESET + " 💰 " + BLUE + BOLD + "AVERAGE PRICE: " + RESET + "₦" + 
                          String.format("%,d", prices.get("avg")) + 
                          String.format("%" + (37 - String.format("%,d", prices.get("avg")).length()) + "s", "") + GREEN + "║" + RESET);
        
        System.out.println(GREEN + "║" + RESET + " 📈 " + PURPLE + BOLD + "PRICE RANGE: " + RESET + "₦" + 
                          String.format("%,d", prices.get("min")) + " - ₦" + String.format("%,d", prices.get("max")) +
                          String.format("%" + (29 - (String.format("%,d", prices.get("min")).length() + String.format("%,d", prices.get("max")).length())) + "s", "") + GREEN + "║" + RESET);
        
        System.out.println(GREEN + "╠══════════════════════════════════════════════════════════════════╣" + RESET);
        System.out.println(GREEN + "║" + YELLOW + " 💡 BARGAINING TIP: Negotiate around the average price for best deals!" + GREEN + " ║" + RESET);
        System.out.println(GREEN + "╚══════════════════════════════════════════════════════════════════╝" + RESET);

        if (wasPartialMatch) {
            System.out.println(BLUE + "🔍 " + BOLD + "Smart search found: " + product + RESET);
        }
    }

    private static void promptForFeedback(String product, Scanner scanner) {
        System.out.println(CYAN + "\n⭐ Rate price accuracy (1-5 stars) or press Enter to skip: " + RESET);
        System.out.print(YELLOW + "Rating (1=Poor, 5=Excellent): " + RESET);
        
        String ratingInput = scanner.nextLine().trim();
        
        if (!ratingInput.isEmpty()) {
            try {
                int rating = Integer.parseInt(ratingInput);
                if (rating >= 1 && rating <= 5) {
                    // Store rating
                    productRatings.computeIfAbsent(product, k -> new ArrayList<>()).add(rating);
                    
                    System.out.print(CYAN + "Optional: Share your market experience: " + RESET);
                    String feedback = scanner.nextLine().trim();
                    
                    if (!feedback.isEmpty()) {
                        productFeedback.computeIfAbsent(product, k -> new ArrayList<>()).add(feedback);
                    }
                    
                    totalFeedbackCount++;
                    
                    System.out.println(GREEN + "✅ Thank you for your feedback! This helps improve our price accuracy." + RESET);
                    displayCurrentRating(product);
                } else {
                    System.out.println(RED + "Please enter a rating between 1 and 5." + RESET);
                }
            } catch (NumberFormatException e) {
                // User chose to skip, no message needed
            }
        }
    }

    private static void displayCurrentRating(String product) {
        List<Integer> ratings = productRatings.get(product);
        if (ratings != null && !ratings.isEmpty()) {
            double avgRating = ratings.stream().mapToInt(Integer::intValue).average().orElse(0.0);
            String stars = "⭐".repeat((int) Math.round(avgRating));
            
            System.out.println(PURPLE + "📊 Current accuracy rating for " + product + ": " + 
                             String.format("%.1f", avgRating) + "/5 " + stars + 
                             " (" + ratings.size() + " reviews)" + RESET);
        }
    }

    private static void displayFeedbackSummary() {
        System.out.println(GREEN + BOLD + "\n╔══════════════════════════════════════════════════════════════════╗" + RESET);
        System.out.println(GREEN + BOLD + "║" + CYAN + BOLD + "                    📊 PRICE ACCURACY REPORT                      " + GREEN + BOLD + "║" + RESET);
        System.out.println(GREEN + BOLD + "╠══════════════════════════════════════════════════════════════════╣" + RESET);
        
        System.out.println(GREEN + BOLD + "║" + RESET + " 📈 " + YELLOW + BOLD + "Total User Feedback: " + RESET + totalFeedbackCount + 
                          String.format("%" + (40 - String.valueOf(totalFeedbackCount).length()) + "s", "") + GREEN + BOLD + "║" + RESET);
        
        if (productRatings.isEmpty()) {
            System.out.println(GREEN + BOLD + "║" + RESET + " 💭 " + BLUE + "No ratings yet. Be the first to rate our prices!              " + GREEN + BOLD + "║" + RESET);
        } else {
            System.out.println(GREEN + BOLD + "╠══════════════════════════════════════════════════════════════════╣" + RESET);
            System.out.println(GREEN + BOLD + "║" + YELLOW + BOLD + "                      TOP RATED PRODUCTS                          " + GREEN + BOLD + "║" + RESET);
            System.out.println(GREEN + BOLD + "╠══════════════════════════════════════════════════════════════════╣" + RESET);
            
            for (Map.Entry<String, List<Integer>> entry : productRatings.entrySet()) {
                String product = entry.getKey();
                List<Integer> ratings = entry.getValue();
                double avgRating = ratings.stream().mapToInt(Integer::intValue).average().orElse(0.0);
                String stars = "⭐".repeat((int) Math.round(avgRating));
                
                String productLine = " 🏷️  " + product.substring(0, 1).toUpperCase() + product.substring(1) + 
                                   ": " + String.format("%.1f", avgRating) + "/5 " + stars + 
                                   " (" + ratings.size() + " reviews)";
                
                System.out.println(GREEN + BOLD + "║" + RESET + productLine + 
                                 String.format("%" + (64 - productLine.length() + 10) + "s", "") + GREEN + BOLD + "║" + RESET);
            }
            
            // Show recent feedback
            if (!productFeedback.isEmpty()) {
                System.out.println(GREEN + BOLD + "╠══════════════════════════════════════════════════════════════════╣" + RESET);
                System.out.println(GREEN + BOLD + "║" + CYAN + BOLD + "                      RECENT USER FEEDBACK                        " + GREEN + BOLD + "║" + RESET);
                System.out.println(GREEN + BOLD + "╠══════════════════════════════════════════════════════════════════╣" + RESET);
                
                int feedbackCount = 0;
                for (Map.Entry<String, List<String>> entry : productFeedback.entrySet()) {
                    if (feedbackCount >= 3) break; // Show only recent 3
                    
                    String product = entry.getKey();
                    List<String> feedbacks = entry.getValue();
                    if (!feedbacks.isEmpty()) {
                        String latestFeedback = feedbacks.get(feedbacks.size() - 1);
                        if (latestFeedback.length() > 50) {
                            latestFeedback = latestFeedback.substring(0, 47) + "...";
                        }
                        
                        System.out.println(GREEN + BOLD + "║" + RESET + " 💬 " + PURPLE + product + ": " + RESET + "\"" + latestFeedback + "\"" +
                                         String.format("%" + (58 - product.length() - latestFeedback.length()) + "s", "") + GREEN + BOLD + "║" + RESET);
                        feedbackCount++;
                    }
                }
            }
        }
        
        System.out.println(GREEN + BOLD + "╠══════════════════════════════════════════════════════════════════╣" + RESET);
        System.out.println(GREEN + BOLD + "║" + BLUE + " 💡 Your feedback helps us improve price accuracy for everyone!     " + GREEN + BOLD + "║" + RESET);
        System.out.println(GREEN + BOLD + "╚══════════════════════════════════════════════════════════════════╝" + RESET);
    }

    private static void displayNotFoundMessage(String userInput, Map<String, Map<String, Integer>> marketPrices) {
        System.out.println(RED + "\n❌ Sorry, no price data found for '" + userInput + "'" + RESET);
        
        // Show similar items
        System.out.println(YELLOW + "\n🔍 Did you mean one of these?" + RESET);
        boolean foundSimilar = false;
        
        for (String item : marketPrices.keySet()) {
            if (item.contains(userInput) || (userInput.length() >= 2 && item.startsWith(userInput.substring(0, 2)))) {
                System.out.println(CYAN + "   • " + item + RESET);
                foundSimilar = true;
            }
        }
        
        if (!foundSimilar) {
            System.out.println(BLUE + "💡 Type 'help' to see all available products" + RESET);
        }
    }

    private static void displayGoodbyeMessage() {
        System.out.println(GREEN + BOLD + "\n╔══════════════════════════════════════════════════════════════════╗" + RESET);
        System.out.println(GREEN + BOLD + "║" + CYAN + "                    🙏 Thank You for Using                        " + GREEN + BOLD + "║" + RESET);
        System.out.println(GREEN + BOLD + "║" + YELLOW + BOLD + "                   MARKET PRICE BOT PRO                           " + GREEN + BOLD + "║" + RESET);
        System.out.println(GREEN + BOLD + "║" + BLUE + "                Happy shopping in Nigerian markets! 🛒             " + GREEN + BOLD + "║" + RESET);
        System.out.println(GREEN + BOLD + "╚══════════════════════════════════════════════════════════════════╝" + RESET);
        System.out.println(PURPLE + "✨ May your bargaining skills bring you the best prices! ✨" + RESET);
    }
}