import java.util.HashMap;
import java.util.Map;
import java.util.Random;
import java.util.Scanner;

public class MarketPriceBot {
    public static void main(String[] args) {
        // Sample dataset of goods and price ranges (#)
        Map<String, Map<String, Integer>> marketPrices = new HashMap<>();

        // Add this in main
        String[] tips = {"Haggle small-small o!", "Check market early for better deals!", "Na beta price", "Ask for bonus if you buy plenty!"};
        Random random = new Random();
        System.out.println(tips[random.nextInt(tips.length)]);



                // Initialize price data
        Map<String, Integer> tomatoPrices = new HashMap<>();
        tomatoPrices.put("min", 2300);
        tomatoPrices.put("max", 2700);
        tomatoPrices.put("avg", 2500);

        Map<String, Integer> yamPrices = new HashMap<>();
        yamPrices.put("min", 3000);
        yamPrices.put("max", 7000);
        yamPrices.put("avg", 5000);

        Map<String, Integer> ricePrices = new HashMap<>();
        ricePrices.put("min", 85000);
        ricePrices.put("max", 100000);
        ricePrices.put("avg", 90000);

        Map<String, Integer> beansPrices = new HashMap<>();
        beansPrices.put("min", 1400);
        beansPrices.put("max", 2500);
        beansPrices.put("avg", 2000);

        Map<String, Integer> flourPrices = new HashMap<>();
        flourPrices.put("min", 14000);
        flourPrices.put("max", 22000);
        flourPrices.put("avg", 16000);

        Map<String, Integer> garriPrices = new HashMap<>();
        garriPrices.put("min", 37000);
        garriPrices.put("max", 45000);
        garriPrices.put("avg", 40000);

        Map<String, Integer> milletPrices = new HashMap<>();
        milletPrices.put("min", 4000);
        milletPrices.put("max", 4500);
        milletPrices.put("avg", 4200);

        Map<String, Integer> groundnutPrices = new HashMap<>();
        groundnutPrices.put("min", 7000);
        groundnutPrices.put("max", 7500);
        groundnutPrices.put("avg", 7150);

        Map<String, Integer> oilPrices = new HashMap<>();
        oilPrices.put("min", 8500);
        oilPrices.put("max", 10000);
        oilPrices.put("avg", 9000);

        Map<String, Integer> sugarPrices = new HashMap<>();
        sugarPrices.put("min", 45000);
        sugarPrices.put("max", 49000);
        sugarPrices.put("avg", 42000);

        Map<String, Integer> saltPrices = new HashMap<>();
        saltPrices.put("min", 2000);
        saltPrices.put("max", 2500);
        saltPrices.put("avg", 1500);

        Map<String, Integer> noodlesPrices = new HashMap<>();
        noodlesPrices.put("min", 8500);
        noodlesPrices.put("max", 10000);
        noodlesPrices.put("avg", 9000);

        // Additional Nigerian staples
        Map<String, Integer> plantainPrices = new HashMap<>();
        plantainPrices.put("min", 1500);
        plantainPrices.put("max", 2200);
        plantainPrices.put("avg", 1800);

        Map<String, Integer> palmOilPrices = new HashMap<>();
        palmOilPrices.put("min", 18000);
        palmOilPrices.put("max", 25000);
        palmOilPrices.put("avg", 22000);

        Map<String, Integer> cassavaPrices = new HashMap<>();
        cassavaPrices.put("min", 15000);
        cassavaPrices.put("max", 20000);
        cassavaPrices.put("avg", 17500);

        Map<String, Integer> onionPrices = new HashMap<>();
        onionPrices.put("min", 18000);
        onionPrices.put("max", 22000);
        onionPrices.put("avg", 20000);

        Map<String, Integer> pepperPrices = new HashMap<>();
        pepperPrices.put("min", 8000);
        pepperPrices.put("max", 12000);
        pepperPrices.put("avg", 10000);

        Map<String, Integer> garlicPrices = new HashMap<>();
        garlicPrices.put("min", 25000);
        garlicPrices.put("max", 30000);
        garlicPrices.put("avg", 27500);

        Map<String, Integer> gingerPrices = new HashMap<>();
        gingerPrices.put("min", 8000);
        gingerPrices.put("max", 12000);
        gingerPrices.put("avg", 10000);

        Map<String, Integer> maizePrices = new HashMap<>();
        maizePrices.put("min", 35000);
        maizePrices.put("max", 42000);
        maizePrices.put("avg", 38500);

        Map<String, Integer> soyabeansPrices = new HashMap<>();
        soyabeansPrices.put("min", 45000);
        soyabeansPrices.put("max", 55000);
        soyabeansPrices.put("avg", 50000);

        Map<String, Integer> fishPrices = new HashMap<>();
        fishPrices.put("min", 12000);
        fishPrices.put("max", 18000);
        fishPrices.put("avg", 15000);

        Map<String, Integer> chickenPrices = new HashMap<>();
        chickenPrices.put("min", 4500);
        chickenPrices.put("max", 6000);
        chickenPrices.put("avg", 5200);

        Map<String, Integer> eggsPrices = new HashMap<>();
        eggsPrices.put("min", 3500);
        eggsPrices.put("max", 4200);
        eggsPrices.put("avg", 3800);


        marketPrices.put("tomato", tomatoPrices);
        marketPrices.put("yam", yamPrices);
        marketPrices.put("rice", ricePrices);
        marketPrices.put("beans", beansPrices);
        marketPrices.put("flour", flourPrices);
        marketPrices.put("garri", garriPrices);
        marketPrices.put("millet", milletPrices);
        marketPrices.put("groundnut", groundnutPrices);
        marketPrices.put("oil", oilPrices);
        marketPrices.put("sugar", sugarPrices);
        marketPrices.put("salt", saltPrices);
        marketPrices.put("noodles", noodlesPrices);
        marketPrices.put("plantain", plantainPrices);
        marketPrices.put("palmoil", palmOilPrices);
        marketPrices.put("cassava", cassavaPrices);
        marketPrices.put("onion", onionPrices);
        marketPrices.put("pepper", pepperPrices);
        marketPrices.put("garlic", garlicPrices);
        marketPrices.put("ginger", gingerPrices);
        marketPrices.put("maize", maizePrices);
        marketPrices.put("soyabeans", soyabeansPrices);
        marketPrices.put("fish", fishPrices);
        marketPrices.put("chicken", chickenPrices);
        marketPrices.put("eggs", eggsPrices);





        // Start the chatbot
        Scanner scanner = new Scanner(System.in);
        System.out.println("Welcome to the Market Price Tracker Chatbot! 🛒");
        System.out.println("Type a good name, 'help' to see all items, or 'quit' to exit.");

        while (true) {
            System.out.print("What good do you want a price for? ");
            String userInput = scanner.nextLine().toLowerCase().trim();

            if (userInput.equals("quit")) {
                System.out.println("Thanks for using the Market Price Tracker! 🙌");
                break;
            }

            if (userInput.equals("help")) {
                System.out.println("\n📋 Available items in our database:");
                System.out.println("🥬 Vegetables: tomato, onion, pepper, garlic, ginger");
                System.out.println("🌾 Grains & Staples: rice, beans, garri, millet, maize, soyabeans, cassava, flour");
                System.out.println("🍌 Fruits: plantain");
                System.out.println("🥜 Others: groundnut, salt, sugar, noodles");
                System.out.println("🛢️ Oils: oil, palmoil");
                System.out.println("🐟 Protein: fish, chicken, eggs");
                System.out.println("\nJust type any item name to get current prices!\n");
                continue;
            }

            // First try exact match
            String foundItem = null;
            if (marketPrices.containsKey(userInput)) {
                foundItem = userInput;
            } else {
                // Try partial search - find items that start with the user input
                for (String item : marketPrices.keySet()) {
                    if (item.startsWith(userInput) && userInput.length() >= 3) {
                        foundItem = item;
                        break;
                    }
                }
            }

            if (foundItem != null) {
                Map<String, Integer> item = marketPrices.get(foundItem);
                System.out.println("\n" + foundItem.substring(0, 1).toUpperCase() + foundItem.substring(1) + " Price Info (per unit):");
                System.out.println("- Average Price: ₦" + String.format("%,d", item.get("avg")));
                System.out.println("- Range: ₦" + String.format("%,d", item.get("min")) + " - ₦" + String.format("%,d", item.get("max")));
                System.out.println("Tip: Bargain around the average price for a fair deal!\n");
                
                // Show suggestion if partial match was used
                if (!foundItem.equals(userInput)) {
                    System.out.println("💡 Found match for: " + foundItem + "\n");
                }
            } else {
                System.out.println("Sorry, I don't have price info for that item.");
                
                // Show similar items if any
                System.out.println("Did you mean one of these?");
                boolean foundSimilar = false;
                for (String item : marketPrices.keySet()) {
                    if (item.contains(userInput) || userInput.contains(item.substring(0, Math.min(3, item.length())))) {
                        System.out.println("- " + item);
                        foundSimilar = true;
                    }
                }
                if (!foundSimilar) {
                    System.out.println("Type 'help' to see all available items or try common items like rice, tomato, or beans.");
                }
                System.out.println();
            }
        }

        scanner.close();
    }
}