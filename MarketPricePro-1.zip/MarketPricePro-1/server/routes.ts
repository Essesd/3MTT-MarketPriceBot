import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertChatMessageSchema } from "@shared/schema";
import { z } from "zod";

export async function registerRoutes(app: Express): Promise<Server> {
  // Get all categories
  app.get("/api/categories", async (req, res) => {
    try {
      const categories = await storage.getCategories();
      res.json(categories);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch categories" });
    }
  });

  // Get all goods
  app.get("/api/goods", async (req, res) => {
    try {
      const { category, minPrice, maxPrice, search } = req.query;
      
      let goods;
      
      if (search) {
        goods = await storage.searchGoods(search as string);
      } else if (category) {
        goods = await storage.getGoodsByCategory(parseInt(category as string));
      } else if (minPrice && maxPrice) {
        goods = await storage.getGoodsByPriceRange(
          parseFloat(minPrice as string),
          parseFloat(maxPrice as string)
        );
      } else {
        goods = await storage.getGoods();
      }
      
      res.json(goods);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch goods" });
    }
  });

  // Get chat messages
  app.get("/api/chat/messages", async (req, res) => {
    try {
      const messages = await storage.getChatMessages();
      res.json(messages);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch chat messages" });
    }
  });

  // Send chat message and get bot response
  app.post("/api/chat/message", async (req, res) => {
    try {
      const validatedData = insertChatMessageSchema.parse({
        ...req.body,
        sender: "user",
        timestamp: new Date().toISOString()
      });

      // Save user message
      const userMessage = await storage.createChatMessage(validatedData);

      // Generate bot response
      const botResponse = await generateBotResponse(validatedData.content);
      const botMessage = await storage.createChatMessage({
        content: botResponse.content,
        sender: "bot",
        timestamp: new Date().toISOString(),
        goodsData: botResponse.goodsData
      });

      res.json({ userMessage, botMessage });
    } catch (error) {
      if (error instanceof z.ZodError) {
        res.status(400).json({ message: "Invalid message format", errors: error.errors });
      } else {
        res.status(500).json({ message: "Failed to send message" });
      }
    }
  });

  // Generate bot response based on user query
  async function generateBotResponse(query: string): Promise<{ content: string; goodsData: string | null }> {
    const lowerQuery = query.toLowerCase();
    
    // Search for relevant goods
    const goods = await storage.searchGoods(query);
    
    if (goods.length > 0) {
      // Return detailed price information
      const goodsData = JSON.stringify(goods);
      const productNames = goods.map(g => g.name).join(", ");
      
      let content = `Here are the current prices for ${productNames} in Nigerian markets:`;
      
      return {
        content,
        goodsData
      };
    } else {
      // Generic responses for common queries
      if (lowerQuery.includes("help") || lowerQuery.includes("how")) {
        return {
          content: "I can help you find current market prices for goods in Nigeria. Try asking about specific items like 'rice prices', 'tomato market', or 'fuel prices'. You can also browse categories using the sidebar.",
          goodsData: null
        };
      } else if (lowerQuery.includes("hello") || lowerQuery.includes("hi")) {
        return {
          content: "Hello! I'm here to help you with Nigerian market prices. What would you like to know about?",
          goodsData: null
        };
      } else {
        return {
          content: "I couldn't find specific information about that item. Please try searching for items like rice, tomatoes, fuel, phones, or other common goods. You can also browse by category using the sidebar.",
          goodsData: null
        };
      }
    }
  }

  const httpServer = createServer(app);
  return httpServer;
}
