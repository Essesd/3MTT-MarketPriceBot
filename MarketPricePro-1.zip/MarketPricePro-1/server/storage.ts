import { users, type User, type InsertUser, type Category, type Good, type ChatMessage, type InsertCategory, type InsertGood, type InsertChatMessage } from "@shared/schema";

export interface IStorage {
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  
  // Categories
  getCategories(): Promise<Category[]>;
  getCategoryById(id: number): Promise<Category | undefined>;
  createCategory(category: InsertCategory): Promise<Category>;
  
  // Goods
  getGoods(): Promise<Good[]>;
  getGoodsByCategory(categoryId: number): Promise<Good[]>;
  getGoodsByPriceRange(minPrice: number, maxPrice: number): Promise<Good[]>;
  searchGoods(query: string): Promise<Good[]>;
  getGoodById(id: number): Promise<Good | undefined>;
  createGood(good: InsertGood): Promise<Good>;
  
  // Chat Messages
  getChatMessages(): Promise<ChatMessage[]>;
  createChatMessage(message: InsertChatMessage): Promise<ChatMessage>;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private categories: Map<number, Category>;
  private goods: Map<number, Good>;
  private chatMessages: Map<number, ChatMessage>;
  private currentUserId: number = 1;
  private currentCategoryId: number = 1;
  private currentGoodId: number = 1;
  private currentMessageId: number = 1;

  constructor() {
    this.users = new Map();
    this.categories = new Map();
    this.goods = new Map();
    this.chatMessages = new Map();
    this.initializeData();
  }

  private initializeData() {
    // Initialize categories
    const categoriesData = [
      { name: "Food & Groceries", count: 45 },
      { name: "Electronics", count: 12 },
      { name: "Clothing", count: 28 },
      { name: "Home & Garden", count: 19 },
      { name: "Transport", count: 8 },
    ];

    categoriesData.forEach(cat => {
      const category: Category = { ...cat, id: this.currentCategoryId++ };
      this.categories.set(category.id, category);
    });

    // Initialize goods with Nigerian market data
    const goodsData = [
      // Food & Groceries (categoryId: 1)
      {
        name: "Local Rice",
        categoryId: 1,
        minPrice: "45000",
        maxPrice: "52000",
        unit: "50kg bag",
        location: "Lagos, Kano markets",
        trend: "+5%",
        lastUpdated: "2 hours ago",
        description: "Premium quality local rice"
      },
      {
        name: "Foreign Rice",
        categoryId: 1,
        minPrice: "68000",
        maxPrice: "75000",
        unit: "50kg bag",
        location: "Lagos, Abuja markets",
        trend: "-2%",
        lastUpdated: "1 hour ago",
        description: "Imported premium rice"
      },
      {
        name: "Tomatoes",
        categoryId: 1,
        minPrice: "800",
        maxPrice: "1200",
        unit: "basket",
        location: "Mile 12, Kano markets",
        trend: "+8%",
        lastUpdated: "3 hours ago",
        description: "Fresh tomatoes"
      },
      {
        name: "Onions",
        categoryId: 1,
        minPrice: "15000",
        maxPrice: "20000",
        unit: "50kg bag",
        location: "Sokoto, Kano markets",
        trend: "+3%",
        lastUpdated: "4 hours ago",
        description: "Fresh red onions"
      },
      {
        name: "Garri",
        categoryId: 1,
        minPrice: "8000",
        maxPrice: "12000",
        unit: "50kg bag",
        location: "Ogun, Lagos markets",
        trend: "0%",
        lastUpdated: "5 hours ago",
        description: "Premium white garri"
      },
      // Electronics (categoryId: 2)
      {
        name: "Samsung Galaxy A14",
        categoryId: 2,
        minPrice: "180000",
        maxPrice: "220000",
        unit: "unit",
        location: "Computer Village, Lagos",
        trend: "-5%",
        lastUpdated: "1 hour ago",
        description: "Latest Samsung smartphone"
      },
      {
        name: "iPhone 13",
        categoryId: 2,
        minPrice: "650000",
        maxPrice: "750000",
        unit: "unit",
        location: "Computer Village, Lagos",
        trend: "-3%",
        lastUpdated: "2 hours ago",
        description: "Apple iPhone 13"
      },
      // Transport (categoryId: 5)
      {
        name: "Petrol",
        categoryId: 5,
        minPrice: "600",
        maxPrice: "650",
        unit: "litre",
        location: "Nationwide",
        trend: "+2%",
        lastUpdated: "30 minutes ago",
        description: "Premium motor spirit"
      },
      {
        name: "Diesel",
        categoryId: 5,
        minPrice: "800",
        maxPrice: "900",
        unit: "litre",
        location: "Nationwide",
        trend: "+1%",
        lastUpdated: "1 hour ago",
        description: "Automotive gas oil"
      }
    ];

    goodsData.forEach(good => {
      const goodItem: Good = { ...good, id: this.currentGoodId++ };
      this.goods.set(goodItem.id, goodItem);
    });

    // Add welcome message
    const welcomeMessage: ChatMessage = {
      id: this.currentMessageId++,
      content: "Hello! I'm MarketPriceBot. I can help you find current prices for goods in Nigerian markets. Try asking me about any product!",
      sender: "bot",
      timestamp: new Date().toISOString(),
      goodsData: null
    };
    this.chatMessages.set(welcomeMessage.id, welcomeMessage);
  }

  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.currentUserId++;
    const user: User = { ...insertUser, id };
    this.users.set(id, user);
    return user;
  }

  async getCategories(): Promise<Category[]> {
    return Array.from(this.categories.values());
  }

  async getCategoryById(id: number): Promise<Category | undefined> {
    return this.categories.get(id);
  }

  async createCategory(category: InsertCategory): Promise<Category> {
    const id = this.currentCategoryId++;
    const newCategory: Category = { ...category, id };
    this.categories.set(id, newCategory);
    return newCategory;
  }

  async getGoods(): Promise<Good[]> {
    return Array.from(this.goods.values());
  }

  async getGoodsByCategory(categoryId: number): Promise<Good[]> {
    return Array.from(this.goods.values()).filter(good => good.categoryId === categoryId);
  }

  async getGoodsByPriceRange(minPrice: number, maxPrice: number): Promise<Good[]> {
    return Array.from(this.goods.values()).filter(good => {
      const goodMinPrice = parseFloat(good.minPrice);
      const goodMaxPrice = parseFloat(good.maxPrice);
      return goodMinPrice >= minPrice && goodMaxPrice <= maxPrice;
    });
  }

  async searchGoods(query: string): Promise<Good[]> {
    const searchTerm = query.toLowerCase();
    return Array.from(this.goods.values()).filter(good =>
      good.name.toLowerCase().includes(searchTerm) ||
      good.description?.toLowerCase().includes(searchTerm)
    );
  }

  async getGoodById(id: number): Promise<Good | undefined> {
    return this.goods.get(id);
  }

  async createGood(good: InsertGood): Promise<Good> {
    const id = this.currentGoodId++;
    const newGood: Good = { ...good, id };
    this.goods.set(id, newGood);
    return newGood;
  }

  async getChatMessages(): Promise<ChatMessage[]> {
    return Array.from(this.chatMessages.values()).sort((a, b) => a.id - b.id);
  }

  async createChatMessage(message: InsertChatMessage): Promise<ChatMessage> {
    const id = this.currentMessageId++;
    const newMessage: ChatMessage = { ...message, id };
    this.chatMessages.set(id, newMessage);
    return newMessage;
  }
}

export const storage = new MemStorage();
