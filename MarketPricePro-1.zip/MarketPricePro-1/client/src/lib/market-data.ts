export interface MarketGood {
  id: number;
  name: string;
  category: string;
  priceRange: string;
  unit: string;
  location: string;
  trend: string;
  lastUpdated: string;
  description?: string;
}

export const SAMPLE_MARKET_DATA: MarketGood[] = [
  {
    id: 1,
    name: "Local Rice",
    category: "Food & Groceries",
    priceRange: "₦45,000 - ₦52,000",
    unit: "50kg bag",
    location: "Lagos, Kano markets",
    trend: "+5%",
    lastUpdated: "2 hours ago",
    description: "Premium quality local rice"
  },
  {
    id: 2,
    name: "Foreign Rice", 
    category: "Food & Groceries",
    priceRange: "₦68,000 - ₦75,000",
    unit: "50kg bag",
    location: "Lagos, Abuja markets",
    trend: "-2%",
    lastUpdated: "1 hour ago",
    description: "Imported premium rice"
  },
  {
    id: 3,
    name: "Tomatoes",
    category: "Food & Groceries", 
    priceRange: "₦800 - ₦1,200",
    unit: "basket",
    location: "Mile 12, Kano markets",
    trend: "+8%",
    lastUpdated: "3 hours ago",
    description: "Fresh tomatoes"
  },
  {
    id: 4,
    name: "Samsung Galaxy A14",
    category: "Electronics",
    priceRange: "₦180,000 - ₦220,000", 
    unit: "unit",
    location: "Computer Village, Lagos",
    trend: "-5%",
    lastUpdated: "1 hour ago",
    description: "Latest Samsung smartphone"
  },
  {
    id: 5,
    name: "Petrol",
    category: "Transport",
    priceRange: "₦600 - ₦650",
    unit: "litre", 
    location: "Nationwide",
    trend: "+2%",
    lastUpdated: "30 minutes ago",
    description: "Premium motor spirit"
  }
];

export const CATEGORIES = [
  "Food & Groceries",
  "Electronics", 
  "Clothing",
  "Home & Garden",
  "Transport"
];

export function searchGoods(query: string): MarketGood[] {
  const searchTerm = query.toLowerCase();
  return SAMPLE_MARKET_DATA.filter(good => 
    good.name.toLowerCase().includes(searchTerm) ||
    good.category.toLowerCase().includes(searchTerm) ||
    good.description?.toLowerCase().includes(searchTerm)
  );
}

export function generateBotResponse(query: string): string {
  const goods = searchGoods(query);
  
  if (goods.length > 0) {
    const productNames = goods.map(g => g.name).join(", ");
    return `Here are the current prices for ${productNames} in Nigerian markets:`;
  } else {
    return "I couldn't find specific information about that item. Please try searching for rice, tomatoes, fuel, phones, or other common goods.";
  }
}
