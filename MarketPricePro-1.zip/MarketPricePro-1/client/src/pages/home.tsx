import { useState } from "react";
import Header from "@/components/header";
import Sidebar from "@/components/sidebar";
import ChatInterface from "@/components/chat-interface";
import HelpModal from "@/components/help-modal";
import { Button } from "@/components/ui/button";
import { HelpCircle } from "lucide-react";

export default function Home() {
  const [selectedCategory, setSelectedCategory] = useState<number | null>(null);
  const [priceRange, setPriceRange] = useState<{ min: number; max: number } | null>(null);
  const [isHelpModalOpen, setIsHelpModalOpen] = useState(false);

  return (
    <div className="min-h-screen bg-gray-50">
      <Header />
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
        <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
          <div className="lg:col-span-1">
            <Sidebar
              selectedCategory={selectedCategory}
              onCategorySelect={setSelectedCategory}
              priceRange={priceRange}
              onPriceRangeChange={setPriceRange}
            />
          </div>
          
          <div className="lg:col-span-3">
            <ChatInterface
              selectedCategory={selectedCategory}
              priceRange={priceRange}
            />
            
            {/* Quick Actions */}
            <div className="mt-6 grid grid-cols-1 md:grid-cols-3 gap-4">
              <Button
                variant="outline"
                className="bg-white p-4 h-auto rounded-xl shadow-sm border border-gray-200 hover:shadow-md transition-shadow text-left group justify-start"
              >
                <div className="flex items-center space-x-3">
                  <div className="w-10 h-10 bg-blue-100 rounded-lg flex items-center justify-center group-hover:bg-blue-200 transition-colors">
                    <i className="fas fa-chart-line text-blue-600"></i>
                  </div>
                  <div>
                    <h3 className="font-medium text-gray-900">Price Trends</h3>
                    <p className="text-sm text-gray-500">View market trends</p>
                  </div>
                </div>
              </Button>
              
              <Button
                variant="outline"
                className="bg-white p-4 h-auto rounded-xl shadow-sm border border-gray-200 hover:shadow-md transition-shadow text-left group justify-start"
              >
                <div className="flex items-center space-x-3">
                  <div className="w-10 h-10 bg-purple-100 rounded-lg flex items-center justify-center group-hover:bg-purple-200 transition-colors">
                    <i className="fas fa-map-marker-alt text-purple-600"></i>
                  </div>
                  <div>
                    <h3 className="font-medium text-gray-900">Market Locator</h3>
                    <p className="text-sm text-gray-500">Find nearby markets</p>
                  </div>
                </div>
              </Button>
              
              <Button
                variant="outline"
                className="bg-white p-4 h-auto rounded-xl shadow-sm border border-gray-200 hover:shadow-md transition-shadow text-left group justify-start"
              >
                <div className="flex items-center space-x-3">
                  <div className="w-10 h-10 bg-green-100 rounded-lg flex items-center justify-center group-hover:bg-green-200 transition-colors">
                    <i className="fas fa-bell text-green-600"></i>
                  </div>
                  <div>
                    <h3 className="font-medium text-gray-900">Price Alerts</h3>
                    <p className="text-sm text-gray-500">Set notifications</p>
                  </div>
                </div>
              </Button>
            </div>
          </div>
        </div>
      </div>

      {/* Floating Help Button */}
      <div className="fixed bottom-6 right-6 z-40">
        <Button
          onClick={() => setIsHelpModalOpen(true)}
          className="bg-nigerian-green text-white w-14 h-14 rounded-full shadow-lg hover:bg-green-700 transition-all transform hover:scale-105 p-0"
        >
          <HelpCircle className="h-6 w-6" />
        </Button>
      </div>

      <HelpModal
        isOpen={isHelpModalOpen}
        onClose={() => setIsHelpModalOpen(false)}
      />
    </div>
  );
}
