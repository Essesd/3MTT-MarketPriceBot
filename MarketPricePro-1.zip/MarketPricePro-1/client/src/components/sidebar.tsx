import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import type { Category } from "@shared/schema";

interface SidebarProps {
  selectedCategory: number | null;
  onCategorySelect: (categoryId: number | null) => void;
  priceRange: { min: number; max: number } | null;
  onPriceRangeChange: (range: { min: number; max: number } | null) => void;
}

export default function Sidebar({
  selectedCategory,
  onCategorySelect,
  priceRange,
  onPriceRangeChange,
}: SidebarProps) {
  const [minPrice, setMinPrice] = useState("");
  const [maxPrice, setMaxPrice] = useState("");

  const { data: categories = [], isLoading } = useQuery<Category[]>({
    queryKey: ["/api/categories"],
  });

  const handleApplyFilter = () => {
    const min = parseFloat(minPrice) || 0;
    const max = parseFloat(maxPrice) || Infinity;
    onPriceRangeChange({ min, max });
  };

  const handleClearFilter = () => {
    setMinPrice("");
    setMaxPrice("");
    onPriceRangeChange(null);
  };

  if (isLoading) {
    return (
      <div className="space-y-6">
        <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
          <div className="animate-pulse space-y-2">
            <div className="h-4 bg-gray-200 rounded w-20"></div>
            <div className="space-y-2">
              {[...Array(5)].map((_, i) => (
                <div key={i} className="h-8 bg-gray-200 rounded"></div>
              ))}
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Categories */}
      <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
        <h3 className="font-semibold text-gray-900 mb-4">Categories</h3>
        <div className="space-y-2">
          <Button
            variant={selectedCategory === null ? "default" : "ghost"}
            className="w-full justify-between text-left h-auto py-2 px-3"
            onClick={() => onCategorySelect(null)}
          >
            <span className="text-sm">All Categories</span>
          </Button>
          {categories.map((category) => (
            <Button
              key={category.id}
              variant={selectedCategory === category.id ? "default" : "ghost"}
              className="w-full justify-between text-left h-auto py-2 px-3 hover:bg-pale-green"
              onClick={() =>
                onCategorySelect(
                  selectedCategory === category.id ? null : category.id
                )
              }
            >
              <span className="text-sm text-gray-700">{category.name}</span>
              <span className="text-xs text-gray-500 bg-gray-100 px-2 py-1 rounded-full">
                {category.count}
              </span>
            </Button>
          ))}
        </div>
      </div>

      {/* Price Range Filter */}
      <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
        <h3 className="font-semibold text-gray-900 mb-4">Price Range Filter</h3>
        <div className="space-y-4">
          <div>
            <Label htmlFor="minPrice" className="text-sm text-gray-600 mb-2">
              Minimum Price
            </Label>
            <div className="relative">
              <span className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-500">
                ₦
              </span>
              <Input
                id="minPrice"
                type="number"
                placeholder="0"
                value={minPrice}
                onChange={(e) => setMinPrice(e.target.value)}
                className="pl-8 focus:ring-nigerian-green focus:border-transparent"
              />
            </div>
          </div>
          <div>
            <Label htmlFor="maxPrice" className="text-sm text-gray-600 mb-2">
              Maximum Price
            </Label>
            <div className="relative">
              <span className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-500">
                ₦
              </span>
              <Input
                id="maxPrice"
                type="number"
                placeholder="1000000"
                value={maxPrice}
                onChange={(e) => setMaxPrice(e.target.value)}
                className="pl-8 focus:ring-nigerian-green focus:border-transparent"
              />
            </div>
          </div>
          <div className="flex space-x-2">
            <Button
              onClick={handleApplyFilter}
              className="flex-1 bg-nigerian-green text-white hover:bg-green-700"
            >
              Apply Filter
            </Button>
            {priceRange && (
              <Button
                onClick={handleClearFilter}
                variant="outline"
                className="flex-1"
              >
                Clear
              </Button>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
