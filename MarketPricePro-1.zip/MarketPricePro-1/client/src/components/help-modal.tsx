import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { X } from "lucide-react";

interface HelpModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export default function HelpModal({ isOpen, onClose }: HelpModalProps) {
  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-md">
        <DialogHeader>
          <div className="flex justify-between items-center">
            <DialogTitle className="text-lg font-semibold text-gray-900">
              How to Use MarketPriceBot
            </DialogTitle>
            <Button
              variant="ghost"
              size="icon"
              onClick={onClose}
              className="text-gray-400 hover:text-gray-600"
            >
              <X className="h-4 w-4" />
            </Button>
          </div>
        </DialogHeader>

        <div className="space-y-4">
          <div className="flex items-start space-x-3">
            <div className="w-6 h-6 bg-nigerian-green rounded-full flex items-center justify-center flex-shrink-0 mt-0.5">
              <span className="text-white text-xs font-semibold">1</span>
            </div>
            <div>
              <h4 className="font-medium text-gray-900">Ask About Prices</h4>
              <p className="text-sm text-gray-600">
                Type questions like "What's the price of rice?" or "Show me
                tomato prices"
              </p>
            </div>
          </div>

          <div className="flex items-start space-x-3">
            <div className="w-6 h-6 bg-nigerian-green rounded-full flex items-center justify-center flex-shrink-0 mt-0.5">
              <span className="text-white text-xs font-semibold">2</span>
            </div>
            <div>
              <h4 className="font-medium text-gray-900">Browse Categories</h4>
              <p className="text-sm text-gray-600">
                Use the sidebar to filter by product categories
              </p>
            </div>
          </div>

          <div className="flex items-start space-x-3">
            <div className="w-6 h-6 bg-nigerian-green rounded-full flex items-center justify-center flex-shrink-0 mt-0.5">
              <span className="text-white text-xs font-semibold">3</span>
            </div>
            <div>
              <h4 className="font-medium text-gray-900">Set Price Alerts</h4>
              <p className="text-sm text-gray-600">
                Get notified when prices change for items you're tracking
              </p>
            </div>
          </div>
        </div>

        <Button
          onClick={onClose}
          className="w-full mt-6 bg-nigerian-green text-white hover:bg-green-700"
        >
          Got it!
        </Button>
      </DialogContent>
    </Dialog>
  );
}
