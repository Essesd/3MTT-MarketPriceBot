import { useState, useRef, useEffect } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Send, Search } from "lucide-react";
import type { ChatMessage, Good } from "@shared/schema";

interface ChatInterfaceProps {
  selectedCategory: number | null;
  priceRange: { min: number; max: number } | null;
}

export default function ChatInterface({
  selectedCategory,
  priceRange,
}: ChatInterfaceProps) {
  const [message, setMessage] = useState("");
  const [searchQuery, setSearchQuery] = useState("");
  const [isTyping, setIsTyping] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const queryClient = useQueryClient();
  const { toast } = useToast();

  const { data: messages = [] } = useQuery<ChatMessage[]>({
    queryKey: ["/api/chat/messages"],
  });

  const sendMessageMutation = useMutation({
    mutationFn: async (content: string) => {
      const response = await apiRequest("POST", "/api/chat/message", {
        content,
      });
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/chat/messages"] });
      setMessage("");
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to send message. Please try again.",
        variant: "destructive",
      });
    },
  });

  const handleSendMessage = () => {
    if (!message.trim()) return;
    
    setIsTyping(true);
    sendMessageMutation.mutate(message);
    
    // Simulate typing delay
    setTimeout(() => {
      setIsTyping(false);
    }, 1500);
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      handleSendMessage();
    }
  };

  const handleSearchSubmit = () => {
    if (!searchQuery.trim()) return;
    setMessage(searchQuery);
    setSearchQuery("");
  };

  const suggestedQueries = [
    "Rice prices",
    "Tomato market",
    "Fuel prices",
    "Phone prices",
  ];

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages, isTyping]);

  const formatPrice = (price: string) => {
    return new Intl.NumberFormat("en-NG", {
      style: "currency",
      currency: "NGN",
      minimumFractionDigits: 0,
    }).format(parseFloat(price));
  };

  const renderPriceCards = (goodsData: string) => {
    try {
      const goods: Good[] = JSON.parse(goodsData);
      return (
        <div className="space-y-3 mt-3">
          {goods.map((good) => (
            <div
              key={good.id}
              className="bg-white rounded-lg p-3 border border-gray-200"
            >
              <div className="flex justify-between items-start mb-2">
                <h4 className="font-medium text-gray-900">
                  {good.name} ({good.unit})
                </h4>
                <div className="flex items-center space-x-1">
                  <i
                    className={`fas text-xs ${
                      good.trend.startsWith("+")
                        ? "fa-arrow-up text-trend-orange"
                        : good.trend.startsWith("-")
                        ? "fa-arrow-down text-green-500"
                        : "fa-minus text-gray-500"
                    }`}
                  ></i>
                  <span
                    className={`text-xs ${
                      good.trend.startsWith("+")
                        ? "text-trend-orange"
                        : good.trend.startsWith("-")
                        ? "text-green-500"
                        : "text-gray-500"
                    }`}
                  >
                    {good.trend}
                  </span>
                </div>
              </div>
              <div className="flex justify-between items-center">
                <div>
                  <span className="text-lg font-semibold nigerian-green">
                    {formatPrice(good.minPrice)} - {formatPrice(good.maxPrice)}
                  </span>
                  <p className="text-xs text-gray-500">{good.location}</p>
                </div>
                <div className="text-right">
                  <p className="text-xs text-gray-500">Last updated</p>
                  <p className="text-xs font-medium text-gray-700">
                    {good.lastUpdated}
                  </p>
                </div>
              </div>
            </div>
          ))}
        </div>
      );
    } catch {
      return null;
    }
  };

  return (
    <div className="space-y-6">
      {/* Search Bar */}
      <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
        <div className="relative">
          <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
            <Search className="h-5 w-5 text-gray-400" />
          </div>
          <Input
            type="text"
            placeholder="Ask about prices... e.g., 'What's the price of rice?'"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            onKeyPress={(e) => e.key === "Enter" && handleSearchSubmit()}
            className="pl-10 pr-12 py-3 focus:ring-nigerian-green focus:border-transparent"
          />
          <Button
            onClick={handleSearchSubmit}
            className="absolute inset-y-0 right-0 pr-3 nigerian-green hover:text-green-700 bg-transparent hover:bg-transparent p-0 h-auto"
          >
            <Send className="h-5 w-5" />
          </Button>
        </div>

        {/* Search Suggestions */}
        <div className="mt-4 flex flex-wrap gap-2">
          {suggestedQueries.map((query) => (
            <Button
              key={query}
              variant="outline"
              size="sm"
              onClick={() => setMessage(query)}
              className="bg-pale-green nigerian-green border-green-200 hover:bg-green-100"
            >
              {query}
            </Button>
          ))}
        </div>
      </div>

      {/* Chat Interface */}
      <div className="bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden">
        <div className="p-6 border-b border-gray-200">
          <h2 className="text-lg font-semibold text-gray-900">
            Price Intelligence Chat
          </h2>
          <p className="text-sm text-gray-600">
            Ask me about current market prices in Nigeria
          </p>
        </div>

        {/* Chat Messages */}
        <div className="p-6 space-y-4 min-h-[400px] max-h-[600px] overflow-y-auto">
          {messages.map((msg) => (
            <div
              key={msg.id}
              className={`flex items-start space-x-3 ${
                msg.sender === "user" ? "justify-end" : ""
              }`}
            >
              {msg.sender === "bot" && (
                <div className="w-8 h-8 bg-nigerian-green rounded-full flex items-center justify-center flex-shrink-0">
                  <i className="fas fa-robot text-white text-sm"></i>
                </div>
              )}

              <div
                className={`rounded-lg p-4 max-w-lg ${
                  msg.sender === "user"
                    ? "bg-nigerian-green text-white rounded-tr-none"
                    : "bg-light-green rounded-tl-none"
                }`}
              >
                <p
                  className={
                    msg.sender === "user" ? "text-white" : "text-gray-800"
                  }
                >
                  {msg.content}
                </p>

                {msg.goodsData && renderPriceCards(msg.goodsData)}

                {msg.goodsData && (
                  <div className="mt-3 p-3 bg-yellow-50 rounded-lg border border-yellow-200">
                    <div className="flex items-center space-x-2">
                      <i className="fas fa-info-circle text-yellow-600"></i>
                      <p className="text-sm text-yellow-800">
                        Prices may vary by location and quality. Always verify
                        with local dealers.
                      </p>
                    </div>
                  </div>
                )}

                <span
                  className={`text-xs mt-2 block ${
                    msg.sender === "user" ? "text-green-100" : "text-gray-500"
                  }`}
                >
                  {new Date(msg.timestamp).toLocaleTimeString([], {
                    hour: "2-digit",
                    minute: "2-digit",
                  })}
                </span>
              </div>

              {msg.sender === "user" && (
                <div className="w-8 h-8 bg-gray-300 rounded-full flex items-center justify-center flex-shrink-0">
                  <i className="fas fa-user text-gray-600 text-sm"></i>
                </div>
              )}
            </div>
          ))}

          {/* Typing Indicator */}
          {isTyping && (
            <div className="flex items-start space-x-3">
              <div className="w-8 h-8 bg-nigerian-green rounded-full flex items-center justify-center flex-shrink-0">
                <i className="fas fa-robot text-white text-sm"></i>
              </div>
              <div className="bg-light-green rounded-lg rounded-tl-none p-4">
                <div className="flex space-x-1">
                  <div className="w-2 h-2 bg-gray-400 rounded-full animate-pulse"></div>
                  <div
                    className="w-2 h-2 bg-gray-400 rounded-full animate-pulse"
                    style={{ animationDelay: "0.2s" }}
                  ></div>
                  <div
                    className="w-2 h-2 bg-gray-400 rounded-full animate-pulse"
                    style={{ animationDelay: "0.4s" }}
                  ></div>
                </div>
              </div>
            </div>
          )}

          <div ref={messagesEndRef} />
        </div>

        {/* Chat Input */}
        <div className="p-6 border-t border-gray-200 bg-gray-50">
          <div className="flex space-x-3">
            <Input
              type="text"
              placeholder="Type your price query here..."
              value={message}
              onChange={(e) => setMessage(e.target.value)}
              onKeyPress={handleKeyPress}
              className="flex-1 focus:ring-nigerian-green focus:border-transparent"
              disabled={sendMessageMutation.isPending}
            />
            <Button
              onClick={handleSendMessage}
              disabled={!message.trim() || sendMessageMutation.isPending}
              className="bg-nigerian-green text-white hover:bg-green-700 flex items-center space-x-2"
            >
              <span>Send</span>
              <Send className="h-4 w-4" />
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
}
