import { pgTable, text, serial, integer, boolean, decimal } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const categories = pgTable("categories", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  count: integer("count").notNull().default(0),
});

export const goods = pgTable("goods", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  categoryId: integer("category_id").notNull(),
  minPrice: decimal("min_price", { precision: 10, scale: 2 }).notNull(),
  maxPrice: decimal("max_price", { precision: 10, scale: 2 }).notNull(),
  unit: text("unit").notNull(),
  location: text("location").notNull(),
  trend: text("trend").notNull(), // "+5%", "-2%", "0%"
  lastUpdated: text("last_updated").notNull(),
  description: text("description"),
});

export const chatMessages = pgTable("chat_messages", {
  id: serial("id").primaryKey(),
  content: text("content").notNull(),
  sender: text("sender").notNull(), // "user" or "bot"
  timestamp: text("timestamp").notNull(),
  goodsData: text("goods_data"), // JSON string for bot responses with price data
});

export const insertCategorySchema = createInsertSchema(categories).omit({
  id: true,
});

export const insertGoodSchema = createInsertSchema(goods).omit({
  id: true,
});

export const insertChatMessageSchema = createInsertSchema(chatMessages).omit({
  id: true,
});

export type Category = typeof categories.$inferSelect;
export type Good = typeof goods.$inferSelect;
export type ChatMessage = typeof chatMessages.$inferSelect;
export type InsertCategory = z.infer<typeof insertCategorySchema>;
export type InsertGood = z.infer<typeof insertGoodSchema>;
export type InsertChatMessage = z.infer<typeof insertChatMessageSchema>;

export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
});

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;
